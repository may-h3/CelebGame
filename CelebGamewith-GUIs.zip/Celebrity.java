import java.util.ArrayList;

public class Celebrity 
{
  private String name;
  private String clue;

  public Celebrity(String n, String c) //this is the constructor
  {
    name = n;
    clue = c;
  }

  public String getName() //returns the celebrity's name
  {
    return name;
  }

  public String getClue() //returns the celebrity's fact
  {
    return clue;
  }

  public String toString()
  {
    return name + ": " + clue;
  }
}